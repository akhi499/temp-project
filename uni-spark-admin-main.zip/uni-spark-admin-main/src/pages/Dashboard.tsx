import { Users, UserCheck, BookOpen, TrendingUp } from "lucide-react";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Dashboard() {
  const stats = [
    {
      title: "Total Students",
      value: "2,847",
      change: "+12.5%",
      changeType: "positive" as const,
      icon: Users,
    },
    {
      title: "Active Professors",
      value: "186",
      change: "+3.2%",
      changeType: "positive" as const,
      icon: UserCheck,
    },
    {
      title: "Courses",
      value: "124",
      change: "+5.1%",
      changeType: "positive" as const,
      icon: BookOpen,
    },
    {
      title: "Enrollment Rate",
      value: "94.2%",
      change: "+2.3%",
      changeType: "positive" as const,
      icon: TrendingUp,
    },
  ];

  return (
    <div className="flex-1 space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Welcome back! Here's an overview of your university system.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <StatsCard
            key={stat.title}
            title={stat.title}
            value={stat.value}
            change={stat.change}
            changeType={stat.changeType}
            icon={stat.icon}
          />
        ))}
      </div>

      {/* Recent Activity */}
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="shadow-material">
          <CardHeader>
            <CardTitle>Recent Enrollments</CardTitle>
            <CardDescription>New student registrations this week</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { name: "Sarah Johnson", course: "Computer Science", date: "2 hours ago" },
                { name: "Michael Chen", course: "Mathematics", date: "4 hours ago" },
                { name: "Emily Davis", course: "Psychology", date: "6 hours ago" },
                { name: "David Wilson", course: "Engineering", date: "1 day ago" },
              ].map((enrollment, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <p className="font-medium text-foreground">{enrollment.name}</p>
                    <p className="text-sm text-muted-foreground">{enrollment.course}</p>
                  </div>
                  <p className="text-xs text-muted-foreground">{enrollment.date}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-material">
          <CardHeader>
            <CardTitle>System Status</CardTitle>
            <CardDescription>Current system health and performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { service: "Student Portal", status: "Operational", uptime: "99.9%" },
                { service: "Grade System", status: "Operational", uptime: "99.8%" },
                { service: "Library System", status: "Maintenance", uptime: "97.2%" },
                { service: "Course Registration", status: "Operational", uptime: "99.9%" },
              ].map((service, i) => (
                <div key={i} className="flex items-center justify-between py-2">
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full ${
                      service.status === "Operational" ? "bg-success" : "bg-warning"
                    }`} />
                    <span className="font-medium text-foreground">{service.service}</span>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-foreground">{service.uptime}</p>
                    <p className="text-xs text-muted-foreground">{service.status}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}