export default function Students() {
  return (
    <div className="flex-1 space-y-6 p-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Students</h1>
        <p className="text-muted-foreground mt-2">
          Manage student records and enrollment information
        </p>
      </div>
      
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <p className="text-lg text-muted-foreground">Students page coming soon</p>
          <p className="text-sm text-muted-foreground mt-2">
            This page will contain student management features
          </p>
        </div>
      </div>
    </div>
  );
}